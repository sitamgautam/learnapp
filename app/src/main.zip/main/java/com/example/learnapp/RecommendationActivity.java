package com.example.learnapp;

import android.app.Activity;
import android.os.Bundle;

public class RecommendationActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommendation);
    }
}
